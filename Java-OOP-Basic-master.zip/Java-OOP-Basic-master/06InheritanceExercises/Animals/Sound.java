package Animals;

public interface Sound {

}
