package WildFarm;

public abstract class Felime extends Mammal {

    public Felime(String animalName, String animalType, double animalWeight, String animalLivingRegion) {
        super(animalName, animalType, animalWeight, animalLivingRegion);
    }
}
