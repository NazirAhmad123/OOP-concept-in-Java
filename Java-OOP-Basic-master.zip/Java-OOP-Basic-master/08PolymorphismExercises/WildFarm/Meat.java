package WildFarm;

public class Meat extends Food {
    public Meat (int foodQuantity) {
        super(foodQuantity);
    }
}
